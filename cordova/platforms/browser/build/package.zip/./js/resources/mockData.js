"use strict";

var mockPartials = {
  partials: [{
    "type": "happiness",
    "properType": "Happiness",
    "data": [{
      "id": "user",
      "score": 0
    }, {
      "id": "api",
      "score": 0
    }]
  }, {
    "type": "sadness",
    "properType": "Sadness",
    "data": [{
      "id": "user",
      "score": 0
    }, {
      "id": "api",
      "score": 0
    }]
  }, {
    "type": "surprise",
    "properType": "Surprise",
    "data": [{
      "id": "user",
      "score": 0
    }, {
      "id": "api",
      "score": 0
    }]
  }, {
    "type": "anger",
    "properType": "Anger",
    "data": [{
      "id": "user",
      "score": 0
    }, {
      "id": "api",
      "score": 0
    }]
  }, {
    "type": "neutral",
    "properType": "Neutral",
    "data": [{
      "id": "user",
      "score": 0
    }, {
      "id": "api",
      "score": 0
    }]
  }, {
    "type": "fear",
    "properType": "Fear",
    "data": [{
      "id": "user",
      "score": 0
    }, {
      "id": "api",
      "score": 0
    }]
  }]
};
