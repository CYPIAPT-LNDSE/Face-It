"use strict";

var images = {
  "h19075_1280": [{
    "faceRectangle": {
      "left": 68,
      "top": 97,
      "width": 64,
      "height": 97
    },
    "scores": {
      "anger": 0.00300731952,
      "contempt": 5.14648448E-08,
      "disgust": 9.180124E-06,
      "fear": 0.0001912825,
      "happiness": 0.9875571,
      "neutral": 0.0009861537,
      "sadness": 1.889955E-05,
      "surprise": 0.008229999
    }
  }],
  "h187696_1920": [{
    "faceRectangle": {
      "height": 571,
      "left": 285,
      "top": 161,
      "width": 571
    },
    "scores": {
      "anger": 6.029397E-07,
      "contempt": 3.36813537E-05,
      "disgust": 6.366248E-07,
      "fear": 2.94457365E-08,
      "happiness": 0.993061066,
      "neutral": 0.00689892145,
      "sadness": 3.68238875E-06,
      "surprise": 1.354874E-06
    }
  }],
  "s594519_1920": [{
    "faceRectangle": {
      "height": 340,
      "left": 538,
      "top": 278,
      "width": 340
    },
    "scores": {
      "anger": 0.00117295515,
      "contempt": 3.11555937E-08,
      "disgust": 5.395609E-05,
      "fear": 0.009736914,
      "happiness": 0.00213388773,
      "neutral": 5.04133277E-05,
      "sadness": 0.9691437,
      "surprise": 0.0177081488
    }
  }],
  "su810005_1280": [{
    "faceRectangle": {
      "height": 504,
      "left": 349,
      "top": 22,
      "width": 504
    },
    "scores": {
      "anger": 2.01399848E-06,
      "contempt": 8.645322E-09,
      "disgust": 1.00035027E-06,
      "fear": 4.006906E-05,
      "happiness": 1.12519183E-06,
      "neutral": 1.15005287E-06,
      "sadness": 3.06504266E-09,
      "surprise": 0.999954641
    }
  }],
  "su211505_1280": [{
    "faceRectangle": {
      "height": 424,
      "left": 395,
      "top": 178,
      "width": 424
    },
    "scores": {
      "anger": 0.0100501953,
      "contempt": 0.000286204857,
      "disgust": 0.001489248,
      "fear": 0.01997851,
      "happiness": 3.027972E-06,
      "neutral": 0.0200685672,
      "sadness": 2.47310945E-05,
      "surprise": 0.9480995
    }
  }],

  "a70442_1280": [{
    "faceRectangle": {
      "height": 720,
      "left": 132,
      "top": 377,
      "width": 720
    },
    "scores": {
      "anger": 0.7083158,
      "contempt": 0.000146833059,
      "disgust": 0.13531974,
      "fear": 0.00219003274,
      "happiness": 9.2015E-06,
      "neutral": 0.01994136,
      "sadness": 0.00156404462,
      "surprise": 0.132512987
    }
  }],
  "a921004_1920": [{
    "faceRectangle": {
      "height": 169,
      "left": 595,
      "top": 215,
      "width": 169
    },
    "scores": {
      "anger": 0.996554136,
      "contempt": 4.515462E-08,
      "disgust": 9.39696547E-05,
      "fear": 3.25651054E-05,
      "happiness": 0.000263414753,
      "neutral": 0.000126797284,
      "sadness": 1.0730862E-06,
      "surprise": 0.00292800879
    }
  }],
  "s652552_1280": [{
    "faceRectangle": {
      "height": 775,
      "left": 203,
      "top": 161,
      "width": 775
    },
    "scores": {
      "anger": 2.50124722E-05,
      "contempt": 8.83303E-10,
      "disgust": 2.940495E-06,
      "fear": 0.000158097566,
      "happiness": 0.00121797994,
      "neutral": 3.181957E-06,
      "sadness": 0.998521149,
      "surprise": 7.16485738E-05
    }
  }]
};
