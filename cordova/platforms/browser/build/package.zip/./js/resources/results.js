"use strict";

var results = [];
