/*{*/
//happiness: { "timesTestedForThisEmotion": 8, "timesPlayerGuessThisEmotion": 10 },
//anger: { "timesTestedForThisEmotion": 8, "timesPlayerGuessThisEmotion": 10 },
//contempt: { "timesTestedForThisEmotion": 8, "timesPlayerGuessThisEmotion": 10 },
//fear: { "timesTestedForThisEmotion": 8, "timesPlayerGuessThisEmotion": 10 },
//surprise: { "timesTestedForThisEmotion": 8, "timesPlayerGuessThisEmotion": 10 },
//neutral: { "timesTestedForThisEmotion": 8, "timesPlayerGuessThisEmotion": 10 },
//happiness: { "timesTestedForThisEmotion": 8, "timesPlayerGuessThisEmotion": 10 },
//rounds:{
//timestampAsRoundId:overalPerentageHere
//timestampAsRoundId:overalPerentageHere
//timestampAsRoundId:overalPerentageHere
//timestampAsRoundId:overalPerentageHere
//timestampAsRoundId:overalPerentageHere
//timestampAsRoundId:overalPerentageHere
//timestampAsRoundId:overalPerentageHere
//}
/*}*/
"use strict";
