"use strict";

function emotionResultGraph(total, result, element) {

  var margin = { top: 20, right: 20, bottom: 20, left: 20 };
  var height = 200 - margin.top - margin.bottom;
  var width = $(element).width() - margin.left - margin.right;

  var lineData = [{ y: 50, x: 0 }, { y: 50, x: total / 2 }, { y: 50, x: total }];

  var xScale = d3.scaleLinear().domain([0, total]).range([0, width]);
  var yScale = d3.scaleLinear().domain([0, 100]).range([height, 0]);

  var axis = d3.axisBottom().scale(xScale).ticks(2).tickValues([0, 100]);

  var line = d3.line().x(function (d) {
    return xScale(d.x);
  }).y(function (d) {
    return yScale(d.y);
  });

  var svg = d3.select(element).append("svg").attr("width", '100%').attr("height", height).append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  svg.append("path").datum(lineData).attr("d", line);

  svg.selectAll("dot").data(result).enter().append("circle").attr("class", function (d) {
    return d.id === "user" ? "lifetime-graph__dots-user" : "lifetime-graph__dots-api";
  }).attr("r", 12).attr("cx", function (d) {
    return xScale(d.score);
  }).attr("cy", function (d) {
    return yScale(50);
  });
}

function emotionResultGraphPercent(total, result, element) {

  var margin = { top: 20, right: 20, bottom: 20, left: 20 };
  var height = 200 - margin.top - margin.bottom;
  var width = $(element).width() - margin.left - margin.right;

  var lineData = [{ y: 50, x: 0 }, { y: 50, x: result[1].score / 2 }, { y: 50, x: result[1].score }];
  var xScale = d3.scaleLinear().domain([0, result[1].score]).range([0, width]);
  var yScale = d3.scaleLinear().domain([0, 100]).range([height, 0]);

  var axis = d3.axisBottom().scale(xScale).ticks(2).tickValues([0, 100]);

  var line = d3.line().x(function (d) {
    return xScale(d.x);
  }).y(function (d) {
    return yScale(d.y);
  });

  var svg = d3.select(element).append("svg").attr("width", '100%').attr("height", height).append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  svg.append("path").datum(lineData).attr("d", line);

  svg.selectAll("dot").data(result).enter().append("circle").attr("class", function (d) {
    return d.id === "user" ? "lifetime-graph__dots-user" : "lifetime-graph__dots-no-show";
  }).attr("r", 12).attr("cx", function (d) {
    return xScale(d.score);
  }).attr("cy", function (d) {
    return yScale(50);
  });
  svg.append("text").data(result).attr("class", "lifetime-graph__emotion-scale").attr("x", function (d) {
    return xScale(result[0].score) - 10;
  }).attr("y", function (d) {
    return yScale(60);
  }).text(function (d) {
    return Math.round(result[0].score / result[1].score * 100) + '%';
  });
}
